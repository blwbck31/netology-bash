#!/bin/bash
# Скрипт для приветствия пользователя по имени

echo "Введите ваше имя:"
read name
echo "Hello, $name!"
