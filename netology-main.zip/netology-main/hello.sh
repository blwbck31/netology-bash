#!/bin/bash
# Простой скрипт для вывода приветствия

echo "Hello, World!"
